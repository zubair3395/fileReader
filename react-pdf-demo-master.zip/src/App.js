import React from 'react'
import PdfDisplay from './components/PdfDsiplay'
// import FileToPDFConverter from './components/FileToPdfConverter'
import FileViewer from './components/FileToPdfConverter'

const App = () => {
  return (
    <>
      {/* <PdfDisplay/> */}
      {/* <FileToPDFConverter/> */}
      <FileViewer/>
    </>
  )
}

export default App
